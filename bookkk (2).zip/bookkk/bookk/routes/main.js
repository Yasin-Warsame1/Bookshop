module.exports = function(app, shopData) {

    const redirectLogin = (req, res, next) => {
        if (!req.session.userId ) {
        res.redirect('./login')
        } else { next (); }
        }
    const bcrypt = require('bcrypt');


    // Handle our routes
    app.get('/',function(req,res){
        // Render index
        res.render('index.ejs', shopData)
    });
    app.get('/about',function(req,res){
        // Render about
        res.render('about.ejs', shopData);
    });
    app.get('/search', redirectLogin,function(req,res){
        // Render search
        res.render("search.ejs", shopData);
    });
    app.get('/search-result', redirectLogin, function (req, res) {
        //Searching in the database
        //Res.send("You searched for: " + req.query.keyword);

        // Query database to get all the books
        let sqlquery = "SELECT * FROM books WHERE name LIKE '%" + req.query.keyword + "%'"; 
        // Execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                //TODO: Send message
                res.redirect('./'); 
            }
            //Render available books
            let newData = Object.assign({}, shopData, {availableBooks:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });        
    });
    app.get('/register', function (req,res) {
        // Render register
        res.render('register.ejs', shopData);                                                                     
    });                                                                                                 
    app.post('/registered', function (req,res) {
        //Cost factor to determine time for hash
        const saltRounds = 10;
        const plainPassword = req.body.password; 
        let mysqlquery;
        bcrypt.hash(plainPassword, saltRounds, function(err, hashedPassword) {
            // Store data in your database
             mysqlquery = "INSERT INTO users (firstname, lastname, email, username, passwordd, hashedpassword) VALUES (?,?,?,?,?,?)"
              // Saving data in database
              let newrecord = [req.body.first, req.body.last, req.body.email, req.body.username, req.body.password, hashedPassword];
              // Execute sql query
              db.query(mysqlquery, newrecord, (err, result) => {
                if (err) {
                //TODO: Send message
                    return console.error(err.message);
                }
                else{
                //TODO: Send message
                     let hh = ('Hello '+ req.body.first + ' '+ req.body.last +' you are now registered! We will send an email to you at ' + req.body.email + ' Your password is: '+ req.body.password +' and your hashed password is: '+ hashedPassword);
                     res.send(hh);
                }
               });         
                                                
           })

                          
    }); 

    app.get('/login', function (req,res) {
        // Render login
        res.render('login.ejs', shopData);                                                                     
    });   
    app.post('/loggedin', function (req,res) {
        // Store data in your database
        let sqlquery= "SELECT hashedpassword FROM users WHERE username  ='" + req.body.username + "'"; 
        console.log(sqlquery);

        // Execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
           //Print array result
            console.log(result);
            // Create variable hashedPassword
            let hashedPassword;
            //Else if statement to check if result is empty
            if(!result.length){
                // TODO: Send message
                let no=('Unfortunately this acount doesnt exist, please register with Berties Bookshop, thank you!'); 
                res.send(no);
           }
           else {
                hashedPassword = result[0].hashedpassword;
            }
        
            //Bcrypt to compare password and hashed password
            bcrypt.compare(req.body.password, hashedPassword, function(err, result) {
                if (err) {
                // TODO: Handle error
                return console.error(err.message);
                }
                else if (result == true) {
                    // TODO: Send message
                    let re =('Hello ' + req.body.username + ' welcome back to Berties Bookshop!'); 
                    res.send(re);

                    
                
                }
                else {
                // TODO: Send message
                let no=('Unfortunately this acount doesnt exist, please register with Berties Bookshop, thank you!'); 
                res.send(no);
                }
                });
                // Save user session here, when login is successful
                req.session.userId = req.body.username; 
         });
               
    }); 


    app.get('/deleteuser', redirectLogin, function (req,res) {
        // Render deleteuser
        res.render('deleteuser.ejs', shopData);                                                                     
    }); 
    app.post('/deleted', function(req, res) {
        // Query database to delete selected user
        let mysqlquery = "DELETE FROM users WHERE username = ?"; 
        // Create variable
        let deleted = req.body.username + " has been deleted, Goodbye!"
        //Console log deleted
        console.log(deleted);
        let user = [req.body.username];
         // Execute sql query
        db.query(mysqlquery, user, (err, result) => {
           
            if (err) {
                // TODO: Send message
                return console.error(err.message);
            }
            
            else {
                // TODO: Send message
                
                let no=(user + ' has been deleted.'); 
                res.send(no);
                }
         });
    });


    app.get('/list', redirectLogin, function(req, res) {
        // Query database to get all the books
        let sqlquery = "SELECT * FROM books"; 
        // Execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                // TODO: Send message
                res.redirect('./'); 
            }
            // Render books
            let newData = Object.assign({}, shopData, {availableBooks:result});
            console.log(newData)
            // Render list
            res.render("list.ejs", newData)
         });
    });


    app.get('/listuser', redirectLogin, function(req, res) {
        // Query database to get all the users
        let mysqlquery = "SELECT username FROM users"; 
        // Execute sql query
        db.query(mysqlquery, (err, result) => {
            if (err) {
                // TODO: Send message
                res.redirect('./'); 
            }
            // Render users
            let newData = Object.assign({}, shopData, {availableUsers:result});
            console.log(newData)
            // Render listuser
            res.render("listuser.ejs", newData)
         });
    });

    app.get('/addbook',redirectLogin, function (req, res) {
        // Render addbook
        res.render('addbook.ejs', shopData);
     });

     
 
     app.post('/bookadded', function (req,res) {
           // Saving data in database
           let sqlquery = "INSERT INTO books (name, price) VALUES (?,?)";
           // Execute sql query
           let newrecord = [req.body.name, req.body.price];
           db.query(sqlquery, newrecord, (err, result) => {
             if (err) {
                // TODO: Send message
               return console.error(err.message);
             }
             else{
                // TODO: Send message
                res.send(' This book is added to database, name: '+ req.body.name + ' price '+ req.body.price);
             }
           
             });
       });   
       
       app.get('/logout', redirectLogin, (req,res) => {
        req.session.destroy(err => {
        if (err) {
        return res.redirect('./')
        }
        res.send('you are now logged out. <a href='+'./'+'>Home</a>');
        })
        })

       app.get('/bargainbooks', redirectLogin, function(req, res) {
        // Execute sql query
        let sqlquery = "SELECT * FROM books WHERE price < 20";
        db.query(sqlquery, (err, result) => {
          if (err) {
             // TODO: Send message
             res.redirect('./');
          }
          let newData = Object.assign({}, shopData, {availableBooks:result});
          console.log(newData)
          //Render bargain
          res.render("bargains.ejs", newData)
        });
    });       

}
